<?php $__env->startSection('title', $article->title); ?>
<?php $__env->startSection('content'); ?>
                <a class="btn btn-primary my-3" href="<?php echo e(url()->previous()); ?>">Back</a>
                <div class="card">
                    <?php if($article->images->count()): ?>
                        <?php if($article->images->count() > 1): ?>
                            <?php echo $__env->make('partials.carousel', ['images' => $article->images, 'id' => $article->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php else: ?>
                            <img src="<?php echo e($article->images->first()->path); ?>" class="card-img-top" alt="...">
                        <?php endif; ?>
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($article->title); ?></h5>
                        <p class="card-text"><?php echo e($article->body); ?></p>
                        <p class="card-text"><small class="text-muted"><?php echo e($article->user->name); ?></small></p>
                        <p class="card-text"><small class="text-muted">Created <?php echo e($article->created_at->diffForHumans()); ?></small></p>
                        <p class="card-text"><small class="text-muted">Updated <?php echo e($article->updated_at->diffForHumans()); ?></small></p>                    </div>
                </div>

                <div class="card my-2">
                    <div class="card-body">
                       <form action="<?php echo e(route('comment.store', ['article' => $article->id])); ?>" method="POST">
                           <?php echo csrf_field(); ?>
                           <textarea class="form-control mb-2" name="body" placeholder="Write some comment here..."></textarea>
                            <input type="submit" class="btn btn-primary">
                       </form>
                    </div>
                </div>

                <?php $__currentLoopData = $article->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card my-2">
                        <div class="card-body">
                            <?php echo e($comment->body); ?>

                            <p class="card-text"><small class="text-muted"><?php echo e($comment->user->name); ?></small></p>
                            <p class="card-text"><small class="text-muted"><?php echo e($comment->created_at->diffForHumans()); ?></small></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\davrk\mm19\mm19learnlaravel-main\cd\resources\views/article.blade.php ENDPATH**/ ?>