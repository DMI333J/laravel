<?php $__env->startSection('title', 'Articles'); ?>
<?php $__env->startSection('content'); ?>

        <div><?php echo e($articles->links('partials.pagination')); ?></div>
        <div class="row row-cols-4 mt-3">
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col mb-3">
                    <div class="card">
                        <?php if($article->images->count()): ?>
                            <?php if($article->images->count() > 1): ?>
                                <?php echo $__env->make('partials.carousel', ['images' => $article->images, 'id' => $article->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php else: ?>
                                <img src="<?php echo e($article->images->first()->path); ?>" class="card-img-top" alt="...">
                            <?php endif; ?>
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($article->title); ?></h5>
                            <p class="card-text"><?php echo e($article->excerpt); ?></p>
                            <a href="<?php echo e(route( 'article', ['article'=> $article->id] )); ?>" class="btn btn-primary">Read more</a>

                            <a class="card-text">



                                <a href="/articles/author/<?php echo e($article -> user -> id); ?>"> <small class="text-muted"><?php echo e($article->user->name); ?></small></a><br>


                                <small class="text-muted">Created <?php echo e($article->created_at->diffForHumans()); ?></small><br>
                                <small class="text-muted">Updated <?php echo e($article->updated_at->diffForHumans()); ?></small><br>
                                <small class="text-muted">Comments: <?php echo e($article->comments()->count()); ?></small><br>
                                <small class="text-muted">Likes: <?php echo e($article->likes()->count()); ?></small><br>
                                <a href="/articles/<?php echo e($article->id); ?>/like">
                                    <?php if($article->isLiked): ?>
                                        unlike
                                    <?php else: ?>
                                        like
                                    <?php endif; ?>
                                </a><br>
                                <?php $__currentLoopData = $article->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/articles/tags/<?php echo e($tag->id); ?>" class="text-decoration-none">
                                        <span class="badge rounded-pill bg-secondary"><?php echo e($tag->name); ?></span>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div><?php echo e($articles->links('partials.pagination')); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\davrk\mm19\mm19learnlaravel-main\cd\resources\views/articles.blade.php ENDPATH**/ ?>